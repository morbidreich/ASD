import eu.jacquet80.minigeo.MapWindow;
import eu.jacquet80.minigeo.Point;
import eu.jacquet80.minigeo.Segment;

import java.awt.*;
import java.util.List;
import java.sql.*;

public class App {


    public static void main(String[] args) {

        MapWindow mapWindow;

        Airspace airspace = new Airspace();

        mapWindow = new MapWindow();
        mapWindow.setVisible(true);

        List<Polygon> polygonList = airspace.getPolygonList();

        for(Polygon poly: polygonList) {

            for (int i = 0; i < poly.getFixList().size() - 1; i++) {

                mapWindow.addSegment(new Segment(
                        new Point(poly.getFixList().get(i).getLatitude(), poly.getFixList().get(i).getLongitude()),
                        new Point(poly.getFixList().get(i + 1).getLatitude(), poly.getFixList().get(i + 1).getLongitude()),
                        Color.BLACK
                ));
            }
        }
        //connectToDatabase();
    }

//    private static void connectToDatabase() {
//
//        try {
//            Connection conn = DriverManager.getConnection("jdbc:h2:file:./test", "sa", "");
//
//            Statement statement = conn.createStatement();
//            statement.executeQuery("DROP TABLE IF EXIST TEST");
//            statement.executeQuery("CREATE TABLE TEST(id int primary key, name varchar(30)");
//
//            conn.close();
//        }
//        catch(Exception e) {
//
//        }
//
//    }

    private void displayElements(MapWindow mapWindow, Airspace airspace) {

    }
}
