import java.awt.*;

public class Colors {
    public static final Color CTR_COLOR = new Color(128, 51, 0);
    public static final Color TMA_COLOR = new Color(71, 71, 71);
    public static final Color SID_COLOR = new Color(30, 90, 225);
    public static final Color STAR_COLOR = new Color(184, 141, 71);
}
